(function(){
  const yearEl = document.getElementById('yr');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  const isMobile = () => window.matchMedia && window.matchMedia('(max-width: 819px)').matches;

  function closeAll(){
    document.querySelectorAll('.mega-wrap.mega-open').forEach(el=>{
      el.classList.remove('mega-open');
      const btn = el.querySelector('.mega-trigger');
      if (btn) btn.setAttribute('aria-expanded','false');
    });
  }

  // --- Desktop hover intent (prevents disappearing when moving from tab to panel) ---
  let closeTimer = null;

  function openWrap(wrap){
    if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
    closeAll();
    wrap.classList.add('mega-open');
    const btn = wrap.querySelector('.mega-trigger');
    if (btn) btn.setAttribute('aria-expanded','true');
  }

  function scheduleClose(delay=200){
    if (closeTimer) clearTimeout(closeTimer);
    closeTimer = setTimeout(()=>closeAll(), delay);
  }

  function bindDesktopHover(){
    document.querySelectorAll('.mega-wrap').forEach(wrap=>{
      wrap.addEventListener('mouseenter', ()=>{
        if (isMobile()) return;
        openWrap(wrap);
      });
      wrap.addEventListener('mouseleave', ()=>{
        if (isMobile()) return;
        scheduleClose(220);
      });
      const panel = wrap.querySelector('.mega');
      if (panel){
        panel.addEventListener('mouseenter', ()=>{
          if (isMobile()) return;
          if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
        });
        panel.addEventListener('mouseleave', ()=>{
          if (isMobile()) return;
          scheduleClose(220);
        });
      }
    });
  }

  // --- Mobile-only click toggles ---
  document.addEventListener('click', (e)=>{
    if (!isMobile()) return;
    const t = e.target;
    const trigger = t && t.closest ? t.closest('.mega-trigger') : null;
    if (trigger){
      const wrap = trigger.closest('.mega-wrap');
      const isOpen = wrap.classList.contains('mega-open');
      closeAll();
      if (!isOpen){
        wrap.classList.add('mega-open');
        trigger.setAttribute('aria-expanded','true');
      }
      e.preventDefault();
      return;
    }
    const inside = t && t.closest ? t.closest('.mega-wrap') : null;
    if (!inside) closeAll();
  });

  document.addEventListener('keydown',(e)=>{
    if (e.key === 'Escape') closeAll();
  });

  window.addEventListener('scroll', ()=>{
    if (isMobile()) closeAll();
  }, {passive:true});

  window.addEventListener('resize', ()=>{
    if (!isMobile()) closeAll();
  });

  bindDesktopHover();
})();

// Savvy AI widget logic
// --- Savvy AI widget logic (static demo) ---
(function(){
  const root = document.documentElement;
  const fab = document.getElementById('savvy-fab');
  const btn = document.getElementById('savvy-btn');
  const close = document.getElementById('savvy-close');
  const input = document.getElementById('savvy-input');
  const send = document.getElementById('savvy-send');
  const chat = document.getElementById('savvy-chat');

  function open(){ document.body.classList.add('savvy-open'); }
  function shut(){ document.body.classList.remove('savvy-open'); }

  if (btn) btn.addEventListener('click', (e)=>{ e.preventDefault(); document.body.classList.toggle('savvy-open'); });
  if (close) close.addEventListener('click', (e)=>{ e.preventDefault(); shut(); });

  // click outside closes
  document.addEventListener('click', (e)=>{
    const t = e.target;
    const panel = document.getElementById('savvy-panel');
    if (!panel || !fab) return;
    const inside = (t && t.closest) ? (t.closest('#savvy-panel') || t.closest('#savvy-fab')) : null;
    if (!inside) shut();
  });

  // simple canned responses (no network)
  function respond(q){
    const text = (q || '').toLowerCase();
    if (text.includes('refund')) return "Refunds: Use the POS Refund flow with role-based permissions and full audit logs. For disputes, export the transaction receipt and tender mix report.";
    if (text.includes('inventory')) return "Inventory: Swipe Savvy syncs inventory across locations with ledger-based auditability. Use cycle counts + shrink tracking and set low-stock alerts/replenishment rules.";
    if (text.includes('bopis') || text.includes('pickup')) return "Omni-channel: BOPIS + curbside are supported with real-time order/fulfillment status updates across channels.";
    if (text.includes('pricing') || text.includes('tier')) return "Pricing & tiers: Channel-specific pricing and availability controls are supported. Configure by location, channel, and customer segment.";
    return "I can help. Try asking about: checkout, refunds, inventory, BOPIS, devices, reporting, or Savvy AI marketing.";
  }

  function addMsg(kind, text){
    if (!chat) return;
    const div = document.createElement('div');
    div.className = 'msg ' + kind;
    div.textContent = text;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
  }

  function handleSend(){
    const q = (input && input.value) ? input.value.trim() : "";
    if (!q) return;
    addMsg('you', q);
    if (input) input.value = "";
    window.setTimeout(()=> addMsg('ai', respond(q)), 220);
  }

  if (send) send.addEventListener('click', (e)=>{ e.preventDefault(); handleSend(); open(); });
  if (input) input.addEventListener('keydown', (e)=>{
    if (e.key === 'Enter'){ e.preventDefault(); handleSend(); open(); }
  });
})();
